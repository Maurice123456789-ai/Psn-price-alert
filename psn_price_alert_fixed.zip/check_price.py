#!/usr/bin/env python3
import os
import re
import sys
import requests
from playwright.sync_api import sync_playwright

PRODUCT_URL = "https://www.kinguin.net/category/95893/playstation-network-eur-100-gift-card-nl"
TARGET_PRICE_EUR = 87.00

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID")

def send_telegram(message):
    if not BOT_TOKEN or not CHAT_ID:
        print("Telegram configuratie ontbreekt")
        return False

    response = requests.post(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
        json={
            "chat_id": CHAT_ID,
            "text": message,
            "parse_mode": "HTML",
            "disable_web_page_preview": False,
        },
        timeout=20,
    )
    return response.ok

def get_usd_to_eur_rate():
    r = requests.get(
        "https://api.frankfurter.app/latest?from=USD&to=EUR",
        timeout=20,
    )
    r.raise_for_status()
    return float(r.json()["rates"]["EUR"])

def get_price_eur():
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-dev-shm-usage",
            ],
        )

        context = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/138.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1920, "height": 1080},
            locale="nl-NL",
        )

        page = context.new_page()

        try:
            page.goto(PRODUCT_URL, wait_until="networkidle", timeout=90000)
            page.wait_for_timeout(15000)

            html = page.content()
            with open("kinguin_debug.html", "w", encoding="utf-8") as f:
                f.write(html)

            body = page.locator("body").inner_text()

            with open("kinguin_debug.txt", "w", encoding="utf-8") as f:
                f.write(body)

            prices = re.findall(r"\$([0-9]+\.[0-9]{2})", body)

            if not prices:
                return None

            usd_price = min(float(p) for p in prices)
            return usd_price * get_usd_to_eur_rate()

        finally:
            browser.close()

def main():
    price_eur = get_price_eur()

    if price_eur is None:
        print("Prijs kon niet worden bepaald")
        sys.exit(1)

    print(f"Huidige prijs: €{price_eur:.2f}")

    if price_eur <= TARGET_PRICE_EUR:
        send_telegram(
            f"🔥 <b>PRIJSALERT!</b>\n\n"
            f"🎮 PSN EUR 100 Gift Card NL\n\n"
            f"💰 Prijs: <b>€{price_eur:.2f}</b>\n"
            f"🎯 Target: €{TARGET_PRICE_EUR:.2f}\n\n"
            f"{PRODUCT_URL}"
        )

if __name__ == "__main__":
    main()
